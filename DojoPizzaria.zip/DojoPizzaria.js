// i didn't make these up
// toppings, seafood, spices from https://www.recipepizza.com/toppings/
// sauces from https://www.slicepizzeria.com/category/recipes/pizza-recipes/
// crusts from https://pizzaneed.com/pizza-crusts/
// cheeses from http://www.thehomepizzeria.com/pizza-toppings/cheese-for-pizza/#
var PizzaMenu = {
    "Crusts" : ["hand tossed","deep dish","stuffed","soft","crusty","thin","New Haven","St. Louis","Neapolitan","New York","Detroit","Sicilian","Chicago Deep-Dish","Flatbread/Focaccia","Gluten Free","Vegan Friendly"],
    "Sauces" : ["tomato","marinara","white","pepper","sweet", "Pesto", "BBQ", "Bechemel","Pasta","Creamy Alfredo", "Salsa", "Pumpkin and Beet Marinara","Ranch","Romesco","Sundried Tomato","Wasabi"],
    "Cheeses" : ["mozarella","feta","smoked mozarella","aged provolone","itialian provolone","parmigiano reggiano","grana padno","pecorino romano","smoked gouda","bleu cheese","goat cheese","cream cheese","Boursin","Mascarpone"],
    "Toppings" : ["pepperoni", "sausage", "mushrooms","olives", "peppers", "onions", "tomatos", "pineapple", "ham", "bacon"],
    "Seafoods" : ["anchovies","Cajon Prawns","Crayfish","Lobster","Oysters","Prawns","Salmon","Shrimp","Salmon","Whitebait"],
    "Spices" : ["Basil","Bayleaf","Chives","Cilantro","Dill","Garlic","Jalepeno Peppers","Oregano","Parsley","Pepper"],
};
function random(menuArray,max) {
    var ingredients = [];
    var ingredient = "";
    var rnd = 0;
    var k = 1;
    var duplicate = false;
    while (k <= max) {
        duplicate = false;
        rnd = randomNumber(menuArray.length);
        ingredient = menuArray[rnd];
        for (j = 0; j < ingredients.length; j++) {
            if (ingredients[j] == ingredient) {
                duplicate = true;
            }
        }
        if (duplicate == false) {
            ingredients.push(ingredient);
            k++;    
        }
    }
    return ingredients;
}
function randomNumber(max) {
    // random number logic from:
    // https://developer.mozilla.org/en-US/docs/web/javascript/reference/global_objects/math/random}
    var num = Math.floor(Math.random() * max);
    return num;
}
var Pizza = {
    "crust" : "",
    "sauce" : "",
    "cheeses" : [],
    "toppings" : [],
    "seafood" : [],
    "spices" : [],
    "pizzaInfo": function() {
        console.log("You ordered:");
        console.log(`${this.crust} crust, with,`),
        console.log(`${this.sauce} sauce,`),
        console.log(`these cheeses: ${this.cheeses},`),
        console.log(`and the following toppings: ${this.toppings}.`);
        if (this.seafood.length > 0) {
                console.log(`You also ordered ${this.seafood} from our seafood toppings menu.`);
            }
        if (this.spices.length > 0) {
                console.log(`And to spice things up, you topped it off with ${this.spices}!`);
            }
        }
    }
function pizzaOven(crust, sauce, cheeses, toppings, seafood, spices) {
    Pizza.crust = crust;
    Pizza.sauce = sauce;
    Pizza.cheeses = cheeses;
    Pizza.toppings = toppings;
    if (seafood == null){
        Pizza.seafood = [];
    }
    else {
        Pizza.seafood = seafood;
    }
    if (spices == null) {
        Pizza.spices = [];
    }
    else {
        Pizza.spices = spices;
    }
    return Pizza;
}

function RandomPizza() {
    crust = PizzaMenu.Crusts[randomNumber(PizzaMenu.Crusts.length)];
    sauce = PizzaMenu.Crusts[randomNumber(PizzaMenu.Crusts.length)];
    cheeses = random(PizzaMenu.Cheeses,2);
    toppings = random(PizzaMenu.Toppings,3);
    seafood = random(PizzaMenu.Seafoods,3);
    spices = random(PizzaMenu.Spices,4);

    return pizzaOven(crust,sauce,cheeses,toppings,seafood,spices);
}

var pizza_1 = pizzaOven("deep dish","traditional","mozzarella",["pepperoni","sausage"], new Array(), new Array());
console.log("=====Pizza1======");
pizza_1.pizzaInfo();

console.log("======Pizza 2========");
var pizza_2 = pizzaOven("hand tossed","marinara",["mozarella","feta"],["mushrooms","olives","onions"], new Array(), new Array());
pizza_2.pizzaInfo();

console.log("======Pizza 3========");
var pizza_3 = pizzaOven("soft", "tomato", ["provolone","mozzarella"],["mushrooms","sausage"],["anchovies","salmon","whitebait"],["Basil","Garlic","Jalepeno Peppers"]);
pizza_3.pizzaInfo();

console.log("======Pizza 4========");
var pizza_4 = pizzaOven("New Haven","Creamy Alfredo",["pecorino romano","smoked gouda","feta"],["mushrooms","olives","pineapple","ham"],["anchovies","Cajon Prowns","Lobster"],["Basil","Cilantro","Dill","Garlic"]);
pizza_4.pizzaInfo();

console.log("=======Pizza 5=========");
console.log("Your randomly generated pizza (eat at your own risk):");
var pizza_5 = RandomPizza();
pizza_5.pizzaInfo();